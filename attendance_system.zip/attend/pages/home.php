<html>
    <head>
        <style>
            img{
                padding-left :30px;
                margin : 0px:
                height : 300px;
                width: 1000px;
                box-shadow: 10;
            }
        </style>
    </head>
    <body>
        <!--<div class="page-title">Simple Attendance Management System</div>   -->
        <img src="ams.jpg">
    </body>
</html>